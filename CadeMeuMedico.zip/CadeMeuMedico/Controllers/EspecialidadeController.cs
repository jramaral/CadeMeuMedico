﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CadeMeuMedico.Models;
using System.Data.Entity;

namespace CadeMeuMedico.Controllers
{
    public class EspecialidadeController : Controller
    {
        private EntidadesCadeMeuMedicoDB db = new EntidadesCadeMeuMedicoDB();
        // GET: Especialidade
        public ActionResult Index()
        {
            var especialidade = db.Especialidades.ToList();

            return View(especialidade);
        }

        public ActionResult Adicionar()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Adicionar(Especialidades especialidade)
        {
            if(!string.IsNullOrEmpty(especialidade.Nome))
            {
                db.Especialidades.Add(especialidade);
                db.SaveChanges();
                return RedirectToAction("Index");


            }
            return View(especialidade);
        }
        public ActionResult Editar(int id)
        {
            var especialidade = db.Especialidades.Find(id);

            return View(especialidade);

        }

        [HttpPost]
        public ActionResult Editar(Especialidades especialidade)
        {
            if (!string.IsNullOrEmpty(especialidade.Nome))
            {
                db.Entry(especialidade).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(especialidade);
        }

        [HttpPost]
        public string Excluir(int id)
        {
            try
            {
                var reg = db.Especialidades.Find(id);
                db.Especialidades.Remove(reg);
                db.SaveChanges();
                return Boolean.TrueString;
            }
            catch 
            {
                return Boolean.FalseString;
                
            }
        }

    }
}