﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CadeMeuMedico.Controllers
{
    public class UsuariosController : Controller
    {
        public ActionResult Logout()
        {
            HttpCookie CookieExpires = new HttpCookie("UserCookieAuthentication");
            CookieExpires.Expires = DateTime.Now.AddDays(-1d);
            Response.Cookies.Add(CookieExpires);

            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public JsonResult AutenticacaoDeUsuario(string login, string senha)
        {
            if(Repositorio.RepositorioUsuario.AutenticarUsuario(login, senha))
            {
                return Json(new
                {
                    Ok = true,
                    Mensagem = "Usuário autenticado. Redirecionando..."
                }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new
                {
                    OK = false,
                    Mensagem = "Usuároi não encontrado. Tente novamente"
                }, JsonRequestBehavior.AllowGet);
            }

           
        }
    }
}