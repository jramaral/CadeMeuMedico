﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using CadeMeuMedico.Models;

namespace CadeMeuMedico.Repositorio
{
    public class RepositorioUsuario
    {
        public static bool AutenticarUsuario(string login, string Senha)
        {
            var SenhaCriptografada = FormsAuthentication.HashPasswordForStoringInConfigFile(Senha, "sha1");

            try
            {
                using (EntidadesCadeMeuMedicoDB db = new EntidadesCadeMeuMedicoDB())
                {
                    var AutenticaUsuario = db.Usuarios.Where(x => x.Login == login && x.Senha == SenhaCriptografada).SingleOrDefault();

                    if(AutenticaUsuario == null)
                    {
                        return false;
                    }
                    else
                    {
                        RepositorioCookies.RegistraCookieAutenticacao(AutenticaUsuario.IDUsuario);
                        return true;
                    }
                }


                
            }
            catch (Exception)
            {

                return false;
            }

        }
        public static Usuarios RecuperaUsuarioPorID(long IDUsuario)
        {
            try
            {
                using (EntidadesCadeMeuMedicoDB db = new EntidadesCadeMeuMedicoDB())
                {
                    var usuario = db.Usuarios.Where(u => u.IDUsuario == IDUsuario).SingleOrDefault();
                    return usuario;
                }
            }
            catch (Exception)
            {

                return null;
            }
        }
        public static Usuarios VerificaSeOUsuarioEstaLogado()
        {
            try
            {
                var usuario = HttpContext.Current.Request.Cookies["UserCookieAuthentication"];
                if(usuario==null)
                {
                    return null;
                }
                else
                {
                    long IDUsuario = Convert.ToInt64(Repositorio.RepositorioCriptografia.Descriptografar(usuario.Values["IDUsuario"]));
                    var usuarioRetornado = RecuperaUsuarioPorID(IDUsuario);
                    return usuarioRetornado;
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}