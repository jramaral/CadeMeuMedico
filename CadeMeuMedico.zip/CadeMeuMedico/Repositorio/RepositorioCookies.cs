﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


namespace CadeMeuMedico.Repositorio
{
    public class RepositorioCookies
    {
        public static void RegistraCookieAutenticacao(long IDUsuario )
        {
            //Objeto cookie
            HttpCookie userCookie = new HttpCookie("UserCookieAuthentication");

            userCookie.Values["IDUsuario"] = CadeMeuMedico.Repositorio.RepositorioCriptografia.Criptografar(IDUsuario.ToString());

            //Tempo de vida do cookie
            userCookie.Expires = DateTime.Now.AddDays(1);

            //Aplicação recebe o cooki
            HttpContext.Current.Response.Cookies.Add(userCookie);
        }

        
    }
}