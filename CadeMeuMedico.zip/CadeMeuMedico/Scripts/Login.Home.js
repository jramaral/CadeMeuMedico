﻿$(document).ready(function (){
    $("#status").hide();
    $("#botao-entrar").click(function () {
        $.ajax({
            url: "/Usuarios/AutenticacaoDeUsuario",
            data: { Login: $("#txtLogin").val(), Senha: $("#txtSenha").val() },
            dataType: "json",
            type: "GET",
            async: true,
            beforeSend: function () {
                $("#status").html("Estamos autenticando o usuário. Só um instante...");
                $("#status").show();
            },
            success: function (dados) {
                if (dados.OK) {
                    $("#status").html(dados.Mensagem)
                    $("#status").show();
                }
                else {
                    $("#status").html(dados.Mensagem);
                    $(location).attr('href', '/Home/Index');
                    $("#status").show();
                }
            },
            error: function () {
                $("#status").html(dados.Mensagem);
                $("#status").show()
            }
        });
    });
});