﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CadeMeuMedico.Models
{
    [MetadataType(typeof(UsuarioMetaDado))]
    public partial class Usuarios
    {

    }
    public class UsuarioMetaDado
    {
        public int IDUsuario { get; set; }

        [Required(ErrorMessage ="Nome do usuário de ser informado")]
        [StringLength(80,ErrorMessage ="O Nome do usuário deve possuir no máximo 80 caracteres")]
        public string Nome { get; set; }

        [Required(ErrorMessage ="O login do usuário deve ser informado")]
        [StringLength(30,ErrorMessage ="O Login deve possuir no máximo 30 caracteres")]
        public string Login { get; set; }
        
        [Required(ErrorMessage ="A senha do usuário deve ser informada")]
        [StringLength(100,ErrorMessage ="A senha do usuário deve possuir no máximo 100")]
        public string Senha { get; set; }

        [Required(ErrorMessage ="O Email do usuário deve ser informado")]
        [StringLength(100,ErrorMessage ="O email do usuario deve possuir no máximo 100 caracteres")]
        public string Email { get; set; }

    }
}