﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CadeMeuMedico.Models
{
    [MetadataType(typeof(CidadesMetaDado))]
    public partial class Cidades
    {

    }

    public class CidadesMetaDado
    {
        
        public int IDCidade { get; set; }

        [Required(ErrorMessage ="Obrigatório informar o nome da Cidade")]
        [StringLength(100,ErrorMessage ="Nome da cidade possuir no máximo 100 caracteres")]
        public string Nome { get; set; }
    }
}