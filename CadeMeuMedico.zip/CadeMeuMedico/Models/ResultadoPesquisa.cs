﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CadeMeuMedico.Models
{
    public class ResultadoPesquisa
    {
        public string Nome { get; set; }
        public string Crm { get; set; }
    }
}