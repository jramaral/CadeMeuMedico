﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CadeMeuMedico.Models
{
    public class Pesquisa
    {
        public int IdEspecialidade { get; set; }
        public int IdCidade { get; set; }
    }
}